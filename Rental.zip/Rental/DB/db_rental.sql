-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2021 at 09:19 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_rental`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_barang`
--

CREATE TABLE `tb_barang` (
  `id_barang` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `id_store` int(11) NOT NULL,
  `nama_barang` varchar(255) NOT NULL,
  `tarif_barang` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `stok` int(11) NOT NULL,
  `gambar_barang` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_barang`
--

INSERT INTO `tb_barang` (`id_barang`, `id_user`, `id_kategori`, `id_store`, `nama_barang`, `tarif_barang`, `deskripsi`, `stok`, `gambar_barang`) VALUES
(1, 1, 1, 18, 'Baju Kurung', '50000', 'Baju kurung dhdsjmfjwaesjdnjwnsjewsjwjejjnmweedjndsjndsjnsxjnssxjs', 0, 'hah.jpg'),
(2, 1, 1, 18, 'f', '20000', 'sxz', 2, 'hih.jpg'),
(4, 1, 5, 18, 'Canon eos 1300d kit lesn', '300000', 'kamera dslr canon eos 1300d dengan lensa kit', 1, 'cam1.jpg'),
(5, 2, 5, 33, 'goPro hero 7', '250000', 'gopro hero 7 lenngkap dengan accecoris', 1, 'cam6.jpg'),
(6, 1, 5, 18, 'nikon 3100d dengan lensa kit', '320000', 'kamera dslr nikon 3100d dengan lensa kit dan memori 32Gb', 1, 'cam3.jpg'),
(7, 1, 5, 18, 'mirorless sony a7000', '400000', 'mirorless sony a7000 dengan lensa kit dan memori 16Gb', 1, 'cam4.jpg'),
(8, 1, 5, 18, 'Lensa wide 7artisan 12mm f/2.8 for E-Mount Black', '200000', '7Artisans 12mm f/2.8 lens Characteristics:1. Manual Focus Prime Fixed Lens2. Focal Length 12mm, Maximum Aperture F2.8.3. All-metal body', 0, 'cam5.jpg'),
(9, 1, 6, 18, 'Honda Vario 125', '100000', 'Honda Vario thn 2010\r\ntampa Helm dan minyak kosong', 2, 'kend1.jpg'),
(10, 1, 6, 18, 'Toyota Avanza 2005', '1100000', 'Mobil toyota avanza 2005\r\nfull bensin', 2, 'kend2.png'),
(11, 1, 6, 18, 'Toyota Kijang Inova', '1500000', 'oyota KijangInnova 2021 Baru Hadir Dengan Fitur Canggih Dan Interior Mewah Yang Berkelas. Cek Toyota Kijang Innova Untuk Spek, Fitur, Perbandingan Mobil, Dan Pesan Test Drive. Award Winning MPV. MPV. 7 Kursi. Interior Berkelas. Dashboard Bernuans Sporty.', 1, 'kend4.png'),
(12, 1, 6, 18, 'Honda Brio', '1300000', 'All New Honda Brio, Let\'s break the ordinary with the international quality, sporty and bigger All New Honda Brio! All New Honda Brio Satya sangat pas untuk ', 2, 'kend3.png'),
(13, 2, 6, 33, 'Honda beat', '300000', 'Honda Beat adalah skuter otomatis yang diproduksi oleh Astra Honda Motor di Indonesia. Skuter ini yang diluncurkan sejak tahun 2008 ini dimaksudkan untuk dipasarkan sepeda motor Honda di Indonesia', 0, 'kend5.jpg'),
(14, 1, 1, 36, 'r', '10000', 'h', 4, 'BRGqfjqxawpr6.png'),
(15, 9, 1, 37, 'Baju Seragam', '50000', 'Baju Seragam sekolah ', 2, 'BRGwfi3em2y8i.png'),
(16, 8, 7, 38, 'Bola ', '50000', 'Bola futsal Nike dan Adidas predator yang tidak bisa di download di sini adalah salah satu dari mereka yang y', 12, 'BRGt965eq08k5.png'),
(17, 8, 2, 38, 'leptop', '100000', 'leptop hp Elitebook di dunia ko nyo lai cak nun jauh la la la la long time trade center of merdeka itu', 2, 'BRG042yn4snjf.png'),
(18, 9, 2, 39, 'Laptop', '50000', 'laptop bla bla', 5, 'BRGqecrqq6372.png'),
(20, 10, 3, 40, 'jasapijit', '50000', 'pijit plus tambah minus', -15, 'BRGz3eu3giaup.png');

-- --------------------------------------------------------

--
-- Table structure for table `tb_checkout`
--

CREATE TABLE `tb_checkout` (
  `id_checkout` int(11) NOT NULL,
  `id_barang` int(11) NOT NULL,
  `total_harga` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_kategori`
--

CREATE TABLE `tb_kategori` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(255) NOT NULL,
  `gambar_` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_kategori`
--

INSERT INTO `tb_kategori` (`id_kategori`, `nama_kategori`, `gambar_`) VALUES
(1, 'Pakaian', 'pakaian.png'),
(2, 'Teknologi', 'teknologi.png'),
(3, 'Jasa', 'jasa.png'),
(4, 'Bangunan', 'bangunan.png'),
(5, 'Fotografi', 'fotografi.png'),
(6, 'Kendaraan', 'kendaraan.png'),
(7, 'Hiburan', 'hiburan.png');

-- --------------------------------------------------------

--
-- Table structure for table `tb_log_activity`
--

CREATE TABLE `tb_log_activity` (
  `id_log_activity` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_log_activity`
--

INSERT INTO `tb_log_activity` (`id_log_activity`, `id_user`, `tanggal`, `keterangan`) VALUES
(15, 1, '2021-02-03', 'User Memesan Barang Sewa'),
(16, 1, '2021-02-03', 'User Mengupdate Profile'),
(17, 1, '2021-02-03', 'User Menambahkan Ulasan'),
(18, 1, '2021-02-03', 'User Memesan Barang Sewa'),
(19, 1, '2021-02-03', 'User Menambahkan Ulasan'),
(20, 1, '2021-02-03', 'User Menambah Store'),
(21, 1, '2021-02-03', 'User Menambahkan Barang'),
(22, 1, '2021-02-03', 'User Memesan Barang Sewa'),
(23, 1, '2021-02-03', 'User Memesan Barang Sewa'),
(24, 2, '2021-02-03', 'User Memesan Barang Sewa'),
(25, 2, '2021-02-03', 'User Memesan Barang Sewa'),
(26, 2, '2021-02-04', 'User Memesan Barang Sewa'),
(27, 2, '2021-02-04', 'User Memesan Barang Sewa'),
(28, 2, '2021-02-04', 'User Memesan Barang Sewa'),
(29, 2, '2021-02-04', 'User Menambahkan Ulasan'),
(30, 2, '2021-02-04', 'User Memesan Barang Sewa'),
(31, 2, '2021-02-04', 'User Memesan Barang Sewa'),
(32, 2, '2021-02-04', 'User Memesan Barang Sewa'),
(33, 2, '2021-02-04', 'User Menambahkan Ulasan'),
(34, 2, '2021-02-04', 'User Menambahkan Ulasan'),
(35, 8, '2021-02-04', 'User Mengupdate Profile'),
(36, 9, '2021-02-04', 'User Mengupdate Profile'),
(37, 9, '2021-02-04', 'User Menambah Store'),
(38, 9, '2021-02-04', 'User Menambahkan Barang'),
(39, 8, '2021-02-04', 'User Menambah Store'),
(40, 8, '2021-02-04', 'User Menambahkan Barang'),
(41, 9, '2021-02-04', 'User Memesan Barang Sewa'),
(42, 9, '2021-02-04', 'User Memesan Barang Sewa'),
(43, 8, '2021-02-04', 'User Memesan Barang Sewa'),
(44, 8, '2021-02-04', 'User Memesan Barang Sewa'),
(45, 9, '2021-02-04', 'User Memesan Barang Sewa'),
(46, 8, '2021-02-04', 'User Menambahkan Ulasan'),
(47, 9, '2021-02-04', 'User Menambahkan Ulasan'),
(48, 8, '2021-02-05', 'User Menambahkan Barang'),
(49, 9, '2021-02-05', 'User Memesan Barang Sewa'),
(50, 9, '2021-02-05', 'User Menambah Store'),
(51, 9, '2021-02-05', 'User Menambahkan Barang'),
(52, 2, '2021-02-09', 'User Menambahkan Ulasan'),
(53, 2, '2021-02-09', 'User Mengupdate Profile'),
(54, 2, '2021-02-09', 'User Mengupdate Profile'),
(55, 2, '2021-02-09', 'User Memesan Barang Sewa'),
(56, 8, '2021-02-09', 'User Memesan Barang Sewa'),
(57, 10, '2021-06-21', 'User Menambahkan Barang'),
(58, 8, '2021-06-23', 'User Mengupdate Profile'),
(59, 8, '2021-06-23', 'User Mengupdate Profile'),
(60, 8, '2021-06-23', 'User Mengupdate Profile'),
(61, 8, '2021-06-23', 'User Mengupdate Profile'),
(62, 8, '2021-06-23', 'User Menambahkan Barang'),
(63, 8, '2021-06-23', 'User Mengupdate Profile'),
(64, 8, '2021-06-23', 'User Mengupdate Profile'),
(65, 8, '2021-06-25', 'User Memesan Barang Sewa'),
(66, 10, '2021-06-25', 'User Menambahkan Barang'),
(67, 10, '2021-06-26', 'User Mengupdate Profile'),
(68, 10, '2021-06-26', 'User Mengupdate Profile'),
(69, 10, '2021-06-26', 'User Menambah Store'),
(70, 10, '2021-06-26', 'User Menambahkan Barang'),
(71, 11, '2021-06-26', 'User Memesan Barang Sewa'),
(72, 11, '2021-06-26', 'User Memesan Barang Sewa'),
(73, 11, '2021-06-28', 'User Memesan Barang Sewa'),
(74, 11, '2021-06-28', 'User Memesan Barang Sewa');

-- --------------------------------------------------------

--
-- Table structure for table `tb_sewa_barang`
--

CREATE TABLE `tb_sewa_barang` (
  `id_sewa_barang` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_barang` int(11) NOT NULL,
  `id_status` int(11) NOT NULL,
  `banyak_sewa` int(11) NOT NULL,
  `tanggal_awal` date NOT NULL,
  `tanggal_akhir` date NOT NULL,
  `alamat_penyewa` text NOT NULL,
  `jaminan` varchar(255) NOT NULL,
  `jenis_transaksi` varchar(255) NOT NULL,
  `jenis_pengiriman` varchar(255) NOT NULL,
  `total_harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_sewa_barang`
--

INSERT INTO `tb_sewa_barang` (`id_sewa_barang`, `id_user`, `id_barang`, `id_status`, `banyak_sewa`, `tanggal_awal`, `tanggal_akhir`, `alamat_penyewa`, `jaminan`, `jenis_transaksi`, `jenis_pengiriman`, `total_harga`) VALUES
(22, 2, 13, 5, 1, '2021-02-04', '2021-02-04', 'padang', 'JMN_ekfrnxyxak.png', 'COD', 'COD', 300000),
(23, 2, 13, 2, 2, '2021-02-04', '2021-02-07', 'pekanbaru', 'JMN_hfkxnqgfv4.png', 'COD', 'COD', 2400000),
(24, 2, 4, 2, 1, '2021-02-04', '2021-02-04', 'padang', 'JMN_fijru5txc9.png', 'COD', 'COD', 300000),
(25, 2, 5, 2, 1, '2021-02-04', '2021-02-24', 'padang', 'JMN_hfnda613n2.png', 'COD', 'COD', 5250000),
(26, 2, 5, 2, 1, '2021-02-07', '2021-02-09', 't', 'JMN_48cuzqd3gd.png', 'COD', 'COD', 750000),
(27, 9, 9, 5, 1, '2021-02-04', '2021-02-04', 'padang', 'JMN_3fvngykgim.png', 'COD', 'COD', 100000),
(28, 9, 16, 2, 2, '2021-02-04', '2021-02-06', 'padang', 'JMN_sfmrhw787u.png', 'COD', 'COD', 300000),
(29, 8, 15, 1, 2, '2021-02-04', '2021-02-19', 'Padang, Marapalam', 'JMN_cc90f8d9qb.png', 'COD', 'COD', 1600000),
(30, 8, 15, 4, 1, '2021-02-18', '2021-02-26', 'ggg', 'JMN_5y2r4sk0wh.png', 'COD', 'COD', 450000),
(31, 9, 16, 1, 1, '2021-02-04', '2021-02-04', 'padang', 'JMN_we8r70gv16.png', 'COD', 'COD', 50000),
(32, 9, 2, 1, 1, '2021-02-05', '2021-02-07', 'padang', 'JMN_bxvave0c1b.png', 'COD', 'COD', 60000),
(33, 2, 4, 4, 1, '2021-02-09', '2021-02-12', 'Padang', 'JMN_mr15xxagnk.png', 'COD', 'COD', 1200000),
(34, 8, 8, 1, 1, '2021-02-09', '2021-02-11', 'Padang', 'JMN_9ftdwi5tvb.png', 'COD', 'COD', 600000),
(38, 11, 20, 5, 3, '2021-06-28', '2021-06-30', 'jawa', 'JMN_ufnx4gfh51.png', 'COD', 'COD', 450000);

-- --------------------------------------------------------

--
-- Table structure for table `tb_slider`
--

CREATE TABLE `tb_slider` (
  `id_slider` int(11) NOT NULL,
  `img_slider` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_slider`
--

INSERT INTO `tb_slider` (`id_slider`, `img_slider`) VALUES
(1, 'sld1.jpg'),
(2, 'sld2.jpg'),
(3, 'sld13jpg'),
(4, 'sld4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tb_status`
--

CREATE TABLE `tb_status` (
  `id_status` int(11) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_status`
--

INSERT INTO `tb_status` (`id_status`, `status`) VALUES
(1, 'Diterima'),
(2, 'Selesai'),
(3, 'Diserahkan'),
(4, 'Diajukan'),
(5, 'Ditolak');

-- --------------------------------------------------------

--
-- Table structure for table `tb_store`
--

CREATE TABLE `tb_store` (
  `id_store` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `nama_store` varchar(255) NOT NULL,
  `alamat_store` varchar(255) NOT NULL,
  `telp_store` varchar(20) NOT NULL,
  `wa_store` varchar(50) NOT NULL,
  `ig_store` varchar(50) NOT NULL,
  `gambar_store` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_store`
--

INSERT INTO `tb_store` (`id_store`, `id_user`, `nama_store`, `alamat_store`, `telp_store`, `wa_store`, `ig_store`, `gambar_store`) VALUES
(18, 1, 'Sederhana', 'Padang', '0823458912', '0823458912', '@sederhana', ''),
(33, 2, 'Mobile', 'Padang', '08123940139', '08123940139', '@mobile', ''),
(34, 1, '', '', '', '', '', ''),
(35, 1, 'nana', 'padang', '081240182', '01938291', 'nana\n', 'hihi.jpg'),
(36, 1, 'fff', 'Padang Panjang', '0812345690', '0812345690', '@fff', 'STR_d7v9bua5kr.png'),
(37, 9, 'Silvia Store', 'Padang', '081363131313', '081363131313', 'silviaayu', 'STR_2n9uje1vp4.png'),
(38, 8, 'AditStore.id', 'Padang - Sumatera Barat', '082169774452', '+6282169774452', '@RendhikaAditya', 'STR_g20qrqe5dq.png'),
(39, 9, 'antah', 'padang', '085356417771', '085356417771', '@antah', 'STR_zn4vsz3ve5.png'),
(40, 10, 'storeuser1', 'pasol', '085271324968', '085271324968', 'iguser1', 'STR_2qf2umvhsq.png');

-- --------------------------------------------------------

--
-- Table structure for table `tb_ulasan`
--

CREATE TABLE `tb_ulasan` (
  `id_ulasan` int(11) NOT NULL,
  `id_barang` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `review` text NOT NULL,
  `bintang` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_ulasan`
--

INSERT INTO `tb_ulasan` (`id_ulasan`, `id_barang`, `id_user`, `review`, `bintang`) VALUES
(12, 2, 1, 'bagus\n', '2.5'),
(13, 1, 1, 'good', '3.5'),
(14, 9, 1, 'bagus', '5.0'),
(15, 13, 2, 'bagus', '5.0'),
(16, 5, 3, 'gambar an se file ap tu cak Imin itu se kok bisa masuk baru masuk Islam dan kaum muslimin di seluruh dunia ko nyo lai cak nun jauh di bawah ini adalah', '4.0'),
(17, 4, 2, 'tapi ada juga yang tidak bisa di download di sini adalah salah satu dari mereka yang tidak bisa di download di sini adalah sebuah perusahaan yang tidak bisa wk sobok bg feri yang tenggelam', '5.0'),
(18, 15, 8, 'tapi aku tidak bisa di download di sini adalah salah satu dari mereka yang', '4.0'),
(19, 16, 9, 'good', '5.0'),
(20, 5, 2, 'bola basket di dunia ini', '3.0');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id_user` int(11) NOT NULL,
  `nama_user` varchar(255) NOT NULL,
  `alamat_user` varchar(255) NOT NULL,
  `email_user` varchar(255) NOT NULL,
  `telp_user` varchar(255) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `nama_user`, `alamat_user`, `email_user`, `telp_user`, `username`, `password`) VALUES
(1, 'silvia\n', 'padang', 'silvia@gmail.com', '0812345678', 'silvia', '098'),
(2, 'ayusa', 'padang', 'ayu@gmail.com', '123', 'ayu', '098'),
(5, 'santika', 'padang', 'fjaja', 'fl2542', 'santika', '234'),
(6, 'Rendhika Aditya', 'Kuala tungkal, Jambi', 'aditya0909.a3@gmail.com', '082169774452', 'adit', '123123'),
(7, 'ad', 'a', '', '213', 'ayu', '098'),
(8, 'Rendhika Aditya', 'Kuala Tungkal, Jambi, Indonesia', 'aditya0909.a3@gmail.com', '+6282169774452', 'aditya', '123123'),
(9, 'Silvia Ayu S', 'Padang', 'silvia09@gmail.com', '+6281364356794', 'silviaayu', '123'),
(10, 'user test 1', 'solok', 'user1@gmail.com', '0822666666', 'user1', '123'),
(11, 'user test 2', 'padang', 'user2@gmail.com', '081261736290', 'user2', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_barang`
--
ALTER TABLE `tb_barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indexes for table `tb_checkout`
--
ALTER TABLE `tb_checkout`
  ADD PRIMARY KEY (`id_checkout`);

--
-- Indexes for table `tb_kategori`
--
ALTER TABLE `tb_kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `tb_log_activity`
--
ALTER TABLE `tb_log_activity`
  ADD PRIMARY KEY (`id_log_activity`);

--
-- Indexes for table `tb_sewa_barang`
--
ALTER TABLE `tb_sewa_barang`
  ADD PRIMARY KEY (`id_sewa_barang`);

--
-- Indexes for table `tb_slider`
--
ALTER TABLE `tb_slider`
  ADD PRIMARY KEY (`id_slider`);

--
-- Indexes for table `tb_status`
--
ALTER TABLE `tb_status`
  ADD PRIMARY KEY (`id_status`);

--
-- Indexes for table `tb_store`
--
ALTER TABLE `tb_store`
  ADD PRIMARY KEY (`id_store`);

--
-- Indexes for table `tb_ulasan`
--
ALTER TABLE `tb_ulasan`
  ADD PRIMARY KEY (`id_ulasan`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_barang`
--
ALTER TABLE `tb_barang`
  MODIFY `id_barang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tb_checkout`
--
ALTER TABLE `tb_checkout`
  MODIFY `id_checkout` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_kategori`
--
ALTER TABLE `tb_kategori`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tb_log_activity`
--
ALTER TABLE `tb_log_activity`
  MODIFY `id_log_activity` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `tb_sewa_barang`
--
ALTER TABLE `tb_sewa_barang`
  MODIFY `id_sewa_barang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `tb_slider`
--
ALTER TABLE `tb_slider`
  MODIFY `id_slider` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tb_status`
--
ALTER TABLE `tb_status`
  MODIFY `id_status` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tb_store`
--
ALTER TABLE `tb_store`
  MODIFY `id_store` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `tb_ulasan`
--
ALTER TABLE `tb_ulasan`
  MODIFY `id_ulasan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
